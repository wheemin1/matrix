"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// node_modules/@netlify/functions/dist/main.cjs
var require_main = __commonJS({
  "node_modules/@netlify/functions/dist/main.cjs"(exports2, module2) {
    "use strict";
    var __defProp = Object.defineProperty;
    var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
    var __getOwnPropNames2 = Object.getOwnPropertyNames;
    var __hasOwnProp = Object.prototype.hasOwnProperty;
    var __export = (target, all) => {
      for (var name in all)
        __defProp(target, name, { get: all[name], enumerable: true });
    };
    var __copyProps = (to, from, except, desc) => {
      if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames2(from))
          if (!__hasOwnProp.call(to, key) && key !== except)
            __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
      }
      return to;
    };
    var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
    var main_exports = {};
    __export(main_exports, {
      builder: () => wrapHandler,
      purgeCache: () => purgeCache,
      schedule: () => schedule,
      stream: () => stream
    });
    module2.exports = __toCommonJS(main_exports);
    var BUILDER_FUNCTIONS_FLAG = true;
    var HTTP_STATUS_METHOD_NOT_ALLOWED = 405;
    var METADATA_VERSION = 1;
    var augmentResponse = (response) => {
      if (!response) {
        return response;
      }
      const metadata = { version: METADATA_VERSION, builder_function: BUILDER_FUNCTIONS_FLAG, ttl: response.ttl || 0 };
      return {
        ...response,
        metadata
      };
    };
    var wrapHandler = (handler2) => (event, context, callback) => {
      if (event.httpMethod !== "GET" && event.httpMethod !== "HEAD") {
        return Promise.resolve({
          body: "Method Not Allowed",
          statusCode: HTTP_STATUS_METHOD_NOT_ALLOWED
        });
      }
      const modifiedEvent = {
        ...event,
        multiValueQueryStringParameters: {},
        queryStringParameters: {}
      };
      const wrappedCallback = (error, response) => callback ? callback(error, augmentResponse(response)) : null;
      const execution = handler2(modifiedEvent, context, wrappedCallback);
      if (typeof execution === "object" && typeof execution.then === "function") {
        return execution.then(augmentResponse);
      }
      return execution;
    };
    var import_process = require("process");
    var purgeCache = async (options = {}) => {
      if (globalThis.fetch === void 0) {
        throw new Error(
          "`fetch` is not available. Please ensure you're using Node.js version 18.0.0 or above. Refer to https://ntl.fyi/functions-runtime for more information."
        );
      }
      const payload = {
        cache_tags: options.tags,
        deploy_alias: options.deployAlias
      };
      const token = import_process.env.NETLIFY_PURGE_API_TOKEN || options.token;
      if (import_process.env.NETLIFY_LOCAL && !token) {
        const scope = options.tags?.length ? ` for tags ${options.tags?.join(", ")}` : "";
        console.log(`Skipping purgeCache${scope} in local development.`);
        return;
      }
      if ("siteSlug" in options) {
        payload.site_slug = options.siteSlug;
      } else if ("domain" in options) {
        payload.domain = options.domain;
      } else {
        const siteID = options.siteID || import_process.env.SITE_ID;
        if (!siteID) {
          throw new Error(
            "The Netlify site ID was not found in the execution environment. Please supply it manually using the `siteID` property."
          );
        }
        payload.site_id = siteID;
      }
      if (!token) {
        throw new Error(
          "The cache purge API token was not found in the execution environment. Please supply it manually using the `token` property."
        );
      }
      const headers = {
        "Content-Type": "application/json; charset=utf8",
        Authorization: `Bearer ${token}`
      };
      if (options.userAgent) {
        headers["user-agent"] = options.userAgent;
      }
      const apiURL = options.apiURL || "https://api.netlify.com";
      const response = await fetch(`${apiURL}/api/v1/purge`, {
        method: "POST",
        headers,
        body: JSON.stringify(payload)
      });
      if (!response.ok) {
        throw new Error(`Cache purge API call returned an unexpected status code: ${response.status}`);
      }
    };
    var schedule = (cron, handler2) => handler2;
    var import_node_stream = require("stream");
    var import_node_util = require("util");
    var pipeline = (0, import_node_util.promisify)(import_node_stream.pipeline);
    var stream = (handler2) => awslambda.streamifyResponse(async (event, responseStream, context) => {
      const { body, ...httpResponseMetadata } = await handler2(event, context);
      const responseBody = awslambda.HttpResponseStream.from(responseStream, httpResponseMetadata);
      if (typeof body === "undefined") {
        responseBody.end();
      } else if (typeof body === "string") {
        responseBody.write(body);
        responseBody.end();
      } else {
        await pipeline(body, responseBody);
      }
    });
  }
});

// netlify/functions/analyze.js
var { Handler } = require_main();
function validatePersonalAnalysis(data) {
  const { mode, personalName, personalBirthdate, personalGender } = data;
  if (mode !== "personal") return { success: false, error: { errors: ["\uBAA8\uB4DC\uAC00 'personal'\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4"] } };
  if (!personalName || personalName.length < 1 || personalName.length > 30) {
    return { success: false, error: { errors: ["\uC774\uB984\uC744 1~30\uC790 \uC0AC\uC774\uB85C \uC785\uB825\uD574\uC8FC\uC138\uC694"] } };
  }
  if (!/^[가-힣a-zA-Z\s]+$/.test(personalName)) {
    return { success: false, error: { errors: ["\uC774\uB984\uC740 \uD55C\uAE00, \uC601\uBB38, \uACF5\uBC31\uB9CC \uD3EC\uD568\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4"] } };
  }
  if (!personalBirthdate) {
    return { success: false, error: { errors: ["\uC0DD\uB144\uC6D4\uC77C\uC744 \uC785\uB825\uD574\uC8FC\uC138\uC694"] } };
  }
  const birthDate = new Date(personalBirthdate);
  const now = /* @__PURE__ */ new Date();
  if (isNaN(birthDate.getTime()) || birthDate > now || birthDate.getFullYear() < 1900) {
    return { success: false, error: { errors: ["\uC720\uD6A8\uD55C \uC0DD\uB144\uC6D4\uC77C\uC744 \uC785\uB825\uD574\uC8FC\uC138\uC694 (1900\uB144 \uC774\uD6C4)"] } };
  }
  if (personalGender !== "male" && personalGender !== "female") {
    return { success: false, error: { errors: ["\uC131\uBCC4\uC744 \uC120\uD0DD\uD574\uC8FC\uC138\uC694"] } };
  }
  return { success: true, data: { mode, personalName, personalBirthdate, personalGender } };
}
function validateCoupleAnalysis(data) {
  const { mode, person1Name, person1Birthdate, person1Gender, person2Name, person2Birthdate, person2Gender } = data;
  if (mode !== "couple") return { success: false, error: { errors: ["\uBAA8\uB4DC\uAC00 'couple'\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4"] } };
  if (!person1Name || person1Name.length < 1 || person1Name.length > 30) {
    return { success: false, error: { errors: ["\uCCAB \uBC88\uC9F8 \uC0AC\uB78C\uC758 \uC774\uB984\uC744 1~30\uC790 \uC0AC\uC774\uB85C \uC785\uB825\uD574\uC8FC\uC138\uC694"] } };
  }
  if (!/^[가-힣a-zA-Z\s]+$/.test(person1Name)) {
    return { success: false, error: { errors: ["\uC774\uB984\uC740 \uD55C\uAE00, \uC601\uBB38, \uACF5\uBC31\uB9CC \uD3EC\uD568\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4"] } };
  }
  if (!person1Birthdate) {
    return { success: false, error: { errors: ["\uCCAB \uBC88\uC9F8 \uC0AC\uB78C\uC758 \uC0DD\uB144\uC6D4\uC77C\uC744 \uC785\uB825\uD574\uC8FC\uC138\uC694"] } };
  }
  const birthDate1 = new Date(person1Birthdate);
  const now = /* @__PURE__ */ new Date();
  if (isNaN(birthDate1.getTime()) || birthDate1 > now || birthDate1.getFullYear() < 1900) {
    return { success: false, error: { errors: ["\uC720\uD6A8\uD55C \uC0DD\uB144\uC6D4\uC77C\uC744 \uC785\uB825\uD574\uC8FC\uC138\uC694 (1900\uB144 \uC774\uD6C4)"] } };
  }
  if (person1Gender !== "male" && person1Gender !== "female") {
    return { success: false, error: { errors: ["\uCCAB \uBC88\uC9F8 \uC0AC\uB78C\uC758 \uC131\uBCC4\uC744 \uC120\uD0DD\uD574\uC8FC\uC138\uC694"] } };
  }
  if (!person2Name || person2Name.length < 1 || person2Name.length > 30) {
    return { success: false, error: { errors: ["\uB450 \uBC88\uC9F8 \uC0AC\uB78C\uC758 \uC774\uB984\uC744 1~30\uC790 \uC0AC\uC774\uB85C \uC785\uB825\uD574\uC8FC\uC138\uC694"] } };
  }
  if (!/^[가-힣a-zA-Z\s]+$/.test(person2Name)) {
    return { success: false, error: { errors: ["\uC774\uB984\uC740 \uD55C\uAE00, \uC601\uBB38, \uACF5\uBC31\uB9CC \uD3EC\uD568\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4"] } };
  }
  if (!person2Birthdate) {
    return { success: false, error: { errors: ["\uB450 \uBC88\uC9F8 \uC0AC\uB78C\uC758 \uC0DD\uB144\uC6D4\uC77C\uC744 \uC785\uB825\uD574\uC8FC\uC138\uC694"] } };
  }
  const birthDate2 = new Date(person2Birthdate);
  if (isNaN(birthDate2.getTime()) || birthDate2 > now || birthDate2.getFullYear() < 1900) {
    return { success: false, error: { errors: ["\uC720\uD6A8\uD55C \uC0DD\uB144\uC6D4\uC77C\uC744 \uC785\uB825\uD574\uC8FC\uC138\uC694 (1900\uB144 \uC774\uD6C4)"] } };
  }
  if (person2Gender !== "male" && person2Gender !== "female") {
    return { success: false, error: { errors: ["\uB450 \uBC88\uC9F8 \uC0AC\uB78C\uC758 \uC131\uBCC4\uC744 \uC120\uD0DD\uD574\uC8FC\uC138\uC694"] } };
  }
  return {
    success: true,
    data: {
      mode,
      person1Name,
      person1Birthdate,
      person1Gender,
      person2Name,
      person2Birthdate,
      person2Gender
    }
  };
}
function calculateDestinyMatrix(birthdate, gender) {
  const date = new Date(birthdate);
  const day = date.getDate();
  const month = date.getMonth() + 1;
  const year = date.getFullYear();
  const reduceToTarot = (num) => {
    while (num > 22) {
      num = num.toString().split("").reduce((sum, digit) => sum + parseInt(digit), 0);
    }
    return num === 0 ? 22 : num;
  };
  const coreEnergy = reduceToTarot(day + month + year);
  const spiritualPurpose = reduceToTarot(day + month);
  const behavior = reduceToTarot(day);
  const talent = reduceToTarot(month + year);
  const karma = reduceToTarot(year);
  const additional1 = reduceToTarot(coreEnergy + spiritualPurpose);
  const additional2 = reduceToTarot(coreEnergy + talent);
  const additional3 = reduceToTarot(coreEnergy + karma);
  const additional4 = reduceToTarot(coreEnergy + behavior);
  const outer1 = reduceToTarot(spiritualPurpose + behavior);
  const outer2 = reduceToTarot(spiritualPurpose + talent);
  const outer3 = reduceToTarot(talent + karma);
  const outer4 = reduceToTarot(karma + behavior);
  return {
    coreEnergy,
    spiritualPurpose,
    behavior,
    talent,
    karma,
    additional1,
    additional2,
    additional3,
    additional4,
    outer1,
    outer2,
    outer3,
    outer4
  };
}
var analysesMap = /* @__PURE__ */ new Map();
var currentId = 1;
var handler = async (event, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 204,
      headers,
      body: ""
    };
  }
  try {
    if (event.httpMethod !== "POST") {
      return {
        statusCode: 405,
        headers,
        body: JSON.stringify({ error: "\uC798\uBABB\uB41C HTTP \uBA54\uC18C\uB4DC\uC785\uB2C8\uB2E4." })
      };
    }
    const body = JSON.parse(event.body || "{}");
    const { mode } = body;
    if (mode === "personal") {
      const validation = validatePersonalAnalysis(body);
      if (!validation.success) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: validation.error.errors })
        };
      }
      const { personalName, personalBirthdate, personalGender } = validation.data;
      const matrixPoints = calculateDestinyMatrix(personalBirthdate, personalGender);
      const id = currentId++;
      const analysis = {
        id,
        mode: "personal",
        personalName,
        personalBirthdate,
        personalGender,
        person1Name: null,
        person1Birthdate: null,
        person1Gender: null,
        person2Name: null,
        person2Birthdate: null,
        person2Gender: null,
        matrixPoints: JSON.stringify(matrixPoints),
        createdAt: /* @__PURE__ */ new Date()
      };
      analysesMap.set(id, analysis);
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          id,
          matrixPoints,
          name: personalName,
          birthdate: personalBirthdate,
          mode: "personal"
        })
      };
    } else if (mode === "couple") {
      const validation = validateCoupleAnalysis(body);
      if (!validation.success) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: validation.error.errors })
        };
      }
      const { person1Name, person1Birthdate, person1Gender, person2Name, person2Birthdate, person2Gender } = validation.data;
      const person1Matrix = calculateDestinyMatrix(person1Birthdate, person1Gender);
      const person2Matrix = calculateDestinyMatrix(person2Birthdate, person2Gender);
      const matrixPoints = {
        person1: person1Matrix,
        person2: person2Matrix
      };
      const id = currentId++;
      const analysis = {
        id,
        mode: "couple",
        personalName: null,
        personalBirthdate: null,
        personalGender: null,
        person1Name,
        person1Birthdate,
        person1Gender,
        person2Name,
        person2Birthdate,
        person2Gender,
        matrixPoints: JSON.stringify(matrixPoints),
        createdAt: /* @__PURE__ */ new Date()
      };
      analysesMap.set(id, analysis);
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          id,
          matrixPoints,
          person1: { name: person1Name, birthdate: person1Birthdate },
          person2: { name: person2Name, birthdate: person2Birthdate },
          mode: "couple"
        })
      };
    } else {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "\uC798\uBABB\uB41C \uBAA8\uB4DC\uC785\uB2C8\uB2E4." })
      };
    }
  } catch (error) {
    console.error("Analysis error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: "\uBD84\uC11D \uC911 \uC624\uB958\uAC00 \uBC1C\uC0DD\uD588\uC2B5\uB2C8\uB2E4." })
    };
  }
};
exports.handler = handler;
