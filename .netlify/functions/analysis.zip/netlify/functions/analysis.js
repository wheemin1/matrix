"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// node_modules/@netlify/functions/dist/main.cjs
var require_main = __commonJS({
  "node_modules/@netlify/functions/dist/main.cjs"(exports2, module2) {
    "use strict";
    var __defProp = Object.defineProperty;
    var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
    var __getOwnPropNames2 = Object.getOwnPropertyNames;
    var __hasOwnProp = Object.prototype.hasOwnProperty;
    var __export = (target, all) => {
      for (var name in all)
        __defProp(target, name, { get: all[name], enumerable: true });
    };
    var __copyProps = (to, from, except, desc) => {
      if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames2(from))
          if (!__hasOwnProp.call(to, key) && key !== except)
            __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
      }
      return to;
    };
    var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
    var main_exports = {};
    __export(main_exports, {
      builder: () => wrapHandler,
      purgeCache: () => purgeCache,
      schedule: () => schedule,
      stream: () => stream
    });
    module2.exports = __toCommonJS(main_exports);
    var BUILDER_FUNCTIONS_FLAG = true;
    var HTTP_STATUS_METHOD_NOT_ALLOWED = 405;
    var METADATA_VERSION = 1;
    var augmentResponse = (response) => {
      if (!response) {
        return response;
      }
      const metadata = { version: METADATA_VERSION, builder_function: BUILDER_FUNCTIONS_FLAG, ttl: response.ttl || 0 };
      return {
        ...response,
        metadata
      };
    };
    var wrapHandler = (handler2) => (event, context, callback) => {
      if (event.httpMethod !== "GET" && event.httpMethod !== "HEAD") {
        return Promise.resolve({
          body: "Method Not Allowed",
          statusCode: HTTP_STATUS_METHOD_NOT_ALLOWED
        });
      }
      const modifiedEvent = {
        ...event,
        multiValueQueryStringParameters: {},
        queryStringParameters: {}
      };
      const wrappedCallback = (error, response) => callback ? callback(error, augmentResponse(response)) : null;
      const execution = handler2(modifiedEvent, context, wrappedCallback);
      if (typeof execution === "object" && typeof execution.then === "function") {
        return execution.then(augmentResponse);
      }
      return execution;
    };
    var import_process = require("process");
    var purgeCache = async (options = {}) => {
      if (globalThis.fetch === void 0) {
        throw new Error(
          "`fetch` is not available. Please ensure you're using Node.js version 18.0.0 or above. Refer to https://ntl.fyi/functions-runtime for more information."
        );
      }
      const payload = {
        cache_tags: options.tags,
        deploy_alias: options.deployAlias
      };
      const token = import_process.env.NETLIFY_PURGE_API_TOKEN || options.token;
      if (import_process.env.NETLIFY_LOCAL && !token) {
        const scope = options.tags?.length ? ` for tags ${options.tags?.join(", ")}` : "";
        console.log(`Skipping purgeCache${scope} in local development.`);
        return;
      }
      if ("siteSlug" in options) {
        payload.site_slug = options.siteSlug;
      } else if ("domain" in options) {
        payload.domain = options.domain;
      } else {
        const siteID = options.siteID || import_process.env.SITE_ID;
        if (!siteID) {
          throw new Error(
            "The Netlify site ID was not found in the execution environment. Please supply it manually using the `siteID` property."
          );
        }
        payload.site_id = siteID;
      }
      if (!token) {
        throw new Error(
          "The cache purge API token was not found in the execution environment. Please supply it manually using the `token` property."
        );
      }
      const headers = {
        "Content-Type": "application/json; charset=utf8",
        Authorization: `Bearer ${token}`
      };
      if (options.userAgent) {
        headers["user-agent"] = options.userAgent;
      }
      const apiURL = options.apiURL || "https://api.netlify.com";
      const response = await fetch(`${apiURL}/api/v1/purge`, {
        method: "POST",
        headers,
        body: JSON.stringify(payload)
      });
      if (!response.ok) {
        throw new Error(`Cache purge API call returned an unexpected status code: ${response.status}`);
      }
    };
    var schedule = (cron, handler2) => handler2;
    var import_node_stream = require("stream");
    var import_node_util = require("util");
    var pipeline = (0, import_node_util.promisify)(import_node_stream.pipeline);
    var stream = (handler2) => awslambda.streamifyResponse(async (event, responseStream, context) => {
      const { body, ...httpResponseMetadata } = await handler2(event, context);
      const responseBody = awslambda.HttpResponseStream.from(responseStream, httpResponseMetadata);
      if (typeof body === "undefined") {
        responseBody.end();
      } else if (typeof body === "string") {
        responseBody.write(body);
        responseBody.end();
      } else {
        await pipeline(body, responseBody);
      }
    });
  }
});

// netlify/functions/analysis.js
var { Handler } = require_main();
var analysesMap = /* @__PURE__ */ new Map();
var handler = async (event, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 204,
      headers,
      body: ""
    };
  }
  try {
    if (event.httpMethod !== "GET") {
      return {
        statusCode: 405,
        headers,
        body: JSON.stringify({ error: "\uC798\uBABB\uB41C HTTP \uBA54\uC18C\uB4DC\uC785\uB2C8\uB2E4." })
      };
    }
    const id = parseInt(event.path.split("/").pop() || "0");
    if (isNaN(id) || id <= 0) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "\uC720\uD6A8\uD558\uC9C0 \uC54A\uC740 ID\uC785\uB2C8\uB2E4." })
      };
    }
    const analysis = analysesMap.get(id);
    if (!analysis) {
      return {
        statusCode: 404,
        headers,
        body: JSON.stringify({ error: "\uBD84\uC11D \uACB0\uACFC\uB97C \uCC3E\uC744 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4." })
      };
    }
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        ...analysis,
        matrixPoints: JSON.parse(analysis.matrixPoints)
      })
    };
  } catch (error) {
    console.error("Get analysis error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: "\uBD84\uC11D \uC870\uD68C \uC911 \uC624\uB958\uAC00 \uBC1C\uC0DD\uD588\uC2B5\uB2C8\uB2E4." })
    };
  }
};
exports.handler = handler;
